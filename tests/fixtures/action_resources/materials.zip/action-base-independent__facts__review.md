# AUTO06 四份基础配置来源事实：独立只读审查

2026-10-07。审查对象为 `action-base-binding/frozen-r1-sha256.json` 冻结的四份 pending `avatar_config_binding`；没有修改候选、生产代码、semantic registry 或主库。

## 审查结论

四份材料均真实、一致，但当前 claim 的 **`resource_role=combat_avatar` + `base_root_for_dependency_enumeration` 仍不能批准**。材料证明角色技能参数操作与某份 ConfigAvatar 引用了一组完全相同的 Ability；没有独立证据证明该角色默认加载了这份 ConfigAvatar。把“这一组引用只在一个配置中出现”转换成默认基础挂载，仍然跨过了未证明的关系。

四份均可支持较弱的、另行定义合同的材料事实：**`related_root_for_dependency_enumeration` / `corroborated_candidate`**。这是有限来源、角色、depot、快照下的精确关联事实，允许把该原根加入待分析候选；不称为确证 base、不作为客户端默认挂载、不授予执行、容量或 dispatch 权限。该结论不依赖文件名，也不依赖交叉唯一性；依据是来自已确定角色技能链的原始精确引用与该配置中原始引用相交。

这里给出的是对弱语义的审查意见，**没有把现有 pending 记录改成 approved**。如采用弱语义，应新增明确合同/新修订，再经 current-head/source 准入；不能保留当前强 claim 而只在说明文字中称它为候选。

| 角色 / depot | 完整材料节点 | 配置直接挂载 | 精确参数操作链 | 独立 Ability 名称 | 链条覆盖 | 当前强 claim | 较弱候选关联 |
|---|---:|---:|---:|---:|---|---|---|
| 申鹤 10000063 / 6301 | 14 | 9 | 18 | 6 | 普攻 10、E 7、Q 1 | pending | 可支持 |
| 砂糖 10000043 / 4301 | 8 | 11 | 9 | 3 | 仅普攻 9；本证据无 E/Q 交叉链 | pending | 可支持 |
| 魈 10000026 / 2601 | 11 | 7 | 19 | 4 | 普攻 16、Q 3；本证据无 E 交叉链 | pending | 可支持 |
| 迪卢克 10000016 / 1601 | 14 | 15 | 16 | 6 | 普攻 11、E 3、Q 2 | pending | 可支持 |

18/9/19/16 条操作包含对同一 Ability 不同参数的重复设置，不能当成同样数量的独立身份佐证。表中的挂载数也不是容量、伤害或动作数。

## 独立核对方法与结果

运行本目录 `verify_sources.py`。脚本仅使用 Python 标准库，通过 SQLite URI `mode=ro`、`PRAGMA query_only=ON` 和单个显式只读事务读取主库；未导入或调用作者的匹配器、盘点脚本、资料生成脚本或 production 查询层。比较采用带类型的规范 JSON，避免 Python `True == 1` 等相等语义。

实际核对 485 份完整原始父文件和 549 个定义。对原父 zlib 解压后验证原始字节长度、SHA256、source_manifest、commit、snapshot；对所有 proposal 材料逐项核对 definition 元数据、JSON pointer、完整原节点 SHA、原值和来源 SHA。所有 42 个直接挂载和 62 条佐证操作涉及的 indexed references 都核对其原父 pointer、精确目标名、resolved 目标定义及目标原节点。

具体关系逐段从原节点核对：

1. Avatar.id 与审核主体一致；Avatar.skillDepotId 与 depot.id 一致。
2. depot 的普通攻击/元素战技/爆发技能 ID 指向实际 Skill 行。
3. Skill.proudSkillGroupId 与 10 级 Proud 行的组 ID 一致。
4. Proud.openConfig 与完整 Talent 节点的精确键一致。
5. Talent 中原始操作的 Ability 字段值与 ConfigAvatar 原始挂载数组对应值相同。
6. ConfigAvatar 挂载数组保留原顺序，9/11/7/15 个原项全部存在；所有直接目标在当前索引均 resolved。

四例正式候选及 Kanban/Manekin 对照的原父、原节点均已核验。八个对照节点没有本快照已审核映射所对应的 `IPFAFECPFAE` 挂载字段。这仅是八个有限对照的事实，不产生按文件名排除其他配置的规则。

另独立扫描了主库全部 **472** 个 `avatar_config` 原树，重建原挂载数组的精确引用交叉结果：四例分别仅与各自这份候选相交，独立名称数 6/3/4/6。原树中未见这四个 Avatar.id、combatConfigHash、manekinJsonConfigHash、animatorConfigPathHash 的同类型原值。这只是否定这 472 个已导入原树内的直接标量复现，不能证明其他来源、打包清单或客户端关系不存在，也不能反向推导 hash 算法。

原始验证结果与每条技能/参数/引用链的字段、pointer、原操作均保存在 `source-verification.json`。其中 candidate 来源定位用文件路径作地址，未用文件路径选择角色或推导业务身份。

## 为什么强 claim 仍有缺口

当前证据图是两条箭头相交：

`Avatar → depot → Skill → Proud → Talent → Ability ← ConfigAvatar`

最后一个箭头没有给出 `Avatar → ConfigAvatar`。某个配方、测试配置、变体或未启用配置同样可能引用已存在的角色 Ability；精确交叉能证明关联，却不能仅凭相交证明默认加载。即使这四例在现有导入范围内各自唯一，导入范围本身也不等于游戏全部资源与加载规则。

砂糖证据只覆盖普通攻击，魈证据没有 E，尤其不能用当前交叉链数量暗示三技能完整覆盖。申鹤、迪卢克虽都有普/E/Q 交叉，依旧没有解决默认配置身份。这不是把它们判错，而是严格限制已证明的命题。

`hash_algorithm=not_decoded` 是正确的边界声明。已有设计提到的第三方实现根据图标名/文件名取表，也未为这次强 claim 增加独立的同快照身份边；本审查未将第三方命名习惯当作事实批准依据。

## 可推进的具体路线

**近期可直接推进弱事实。** 改为相关候选根合同，显式写明 `default_mount=unproven`、`whole_avatar_coverage=partial`、`capacity_closure=pending`、`action_dispatch=pending`、`execution_authority=false`。B1 可以枚举这个根及其原始引用，但从该根到“实际生效/启动/容量写入”的每一步仍独立审核；不能因为候选根已准入就默认激活其中所有能力。保留相交证据、未相交挂载和未知字段，不删掉有待判断的部分。

**强事实补证不限定为 hash 解码。** 下列任一可靠方向都可能补足缺边，仍需逐来源审查：

- 同一客户端版本/快照的资源映射清单，直接把 Avatar.combatConfigHash 或明确的配置引用定位到这份完整原资源；保存清单原父、定位链和哈希，而非猜测散列算法。
- 可靠提取工具的可复现导出证据：原资源 ID、导出路径和内容 SHA 的对应，以及该 ID 被这条 Avatar 配置引用的来源。仅“导出文件名相似”不够。
- 可重复的客户端加载观测，记录确切 Avatar/depot、资源身份、实际加载配置内容指纹和触发环境，排除展示/替身/皮肤或特殊模式替代项。观测可以形成有适用范围的经验事实，而非全角色命名规则。
- 后续发现的其他第一手配置字段/父容器关系，只要能把这条 Avatar 身份与原配置内容明确连起来，且版本、来源和变体边界可复核，同样可以使用。

不需要为四个角色写四套算法；新增的是受审来源级关系事实，运行时继续使用通用精确身份和依赖枚举逻辑。

## 完整性与边界

- 主库 SHA256 前后均为 `ea3abaa1cca257c8cc6daa0fcec9006889db7a2cdc0a1afd622e35a011ed7b16`。
- 21 个冻结文件前后哈希均与冻结清单一致。
- 上游 commit：`342084292ba4c3c6ec2bc34c045de4de72ae8d53`。
- snapshot：`8c9106736d92b586d5c0258c2b96600e8b777a308655b7427da16d5b5d6e86d9`。
- 本审查不测试 matcher 反例、semantic current-head 准入、公共根导入或运行时容量；由父审查分别负责。原归一化字段映射沿用本快照既有受审口径，本次核对原 pointer/原字段/原值，未重新签发全量字段映射语义。
